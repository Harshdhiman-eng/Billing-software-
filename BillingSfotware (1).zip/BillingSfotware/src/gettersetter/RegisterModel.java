/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gettersetter;

import employee.PurchasrdItems;

/**
 *
 * @author Indian
 */
public class RegisterModel {
    
    private String name;
    private String email;
    private String password;
    private  String gender;
    private  String phoneno;
    private  String module;
    private  String desc;
    private  String ItemID;
    private  String Category;
    private String image;
    private  String updateItemWithImage;
    private  String PurchasrdItems;
     private  String Price;
    
    public RegisterModel(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }
 public String getdesc() {
        return desc;
    }
      public void setdesc(String desc) {
        this.desc = desc;
    }
    public String getItemID(){
    return ItemID;
    }
      public void setItemID(String ItemID){
      this.ItemID=ItemID;
      }
      public String getCategory(){
      return Category;
      }
     public void setCategory(String Category){
     this.Category=Category;
     }
     
       public String getimage(){
      return  image;
      }
     public void setimage(String  image){
     this. image= image;
     }
   
       public String getupdateItemWithImage(){
      return  updateItemWithImage;
      }
    
        public void setPurchasrdItems(String  PurchasrdItems){
     this. PurchasrdItems= PurchasrdItems;
     }
   
       public String getPurchasrdItems(){
      return  PurchasrdItems;
      }

    public void setPrice(String item_price) {
        this.Price=Price;
    }
      public String getPrice(){
      return  Price;
      }
}


